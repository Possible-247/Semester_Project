#include <iostream>
#include <stdlib.h>
#include <string>
using namespace std;

int main( ) {
	string dial="*110#";
	int menuOpt, option1, option2, option3, option4;
	int choice1, choice2, choice3, accountCH, mPayOpt, ssOption;
	int input, input1, bundleC, Bchoice, bilOpt, buyGopt, Opt;
	string Rnum, Rnum1, tilnum, pin, default_pin, tilnum1, agent_id, new_pin, new_pin1;
	double amount, nbalance, default_balance;
	agent_id="UENR MONEY ENTERPRISE";
	default_balance=2000;
	default_pin="0000";
	tilnum="1111";
	string aCname, aCnumber, aCrdate;
	aCname="EUGENE SIMPSON";
	aCnumber="0543486338";
	aCrdate="15/ 08/ 2000";
	string Menu1[7]={"1. Send Money","2. Withdraw Cash","3. Buy Airtime or Data","4. Financial Services", "5. My Account","6. Make Payments", "7. Self Services"};
    string Menu2[4]={"1. Vodafone Network", "2. Other Network", "3. To Unregistered", "0. Back"};

	//short_code input
	cout<<"DIAL *110# AND FOLLOW THE PROMTS"<<endl;
	cin>>dial;
	system("cls");
	//main menu
    if(dial=="*110#"){
	cout<<"====MENU===="<<endl;
	cout<<Menu1[0]<<endl;
	cout<<Menu1[1]<<endl;
	cout<<Menu1[2]<<endl;
	cout<<Menu1[3]<<endl;
	cout<<Menu1[4]<<endl;
	cout<<Menu1[5]<<endl;
	cout<<Menu1[6]<<endl;
	cout<<"Select an option"<<endl;
	cin>>menuOpt;
	system("cls");
    } 
    
	else if(dial!="*110#"){ 
		cout<<"INVALID USSD CODE!"<<endl;
        }
    else{
    	cout<<"UNKNOWN APPLICATION"<<endl;
	}    
	
	switch(menuOpt){
		//send money menu
		case 1:
			cout<<"====Send Money===="<<endl;
			cout<<Menu2[0]<<endl;
			cout<<Menu2[1]<<endl;
			cout<<Menu2[2]<<endl;
			cout<<Menu2[3]<<endl;
			cout<<"Enter an option"<<endl;
			cin>>option1;
			system("cls");
			
			if(option1==1){
				cout<<"Enter recipient number"<<endl;
				cin>>Rnum;
				cout<<"Confirm recipient number"<<endl;
				cin>>Rnum1;
				system("cls");
				
					cout<<"Enter amount to send"<<endl;
					cin>>amount;
					system("cls");
					
					cout<<"Enter pin to confirm"<<endl;
					cin>>pin;
					system("cls");
					
					if(pin==default_pin&&Rnum==Rnum1){
						cout<<"You have successfully send GHC: "<<amount<<" to "<<Rnum1<<endl;
						cout<<"Your current balance is GHC: "<<default_balance-amount<<endl;
					}
				
				else if(Rnum!=Rnum1){
					cout<<"Numbers does not match...Enter number again"<<endl;	
				}
				else{
					cout<<"Invalid number"<<endl;
				}
			}
			else if(option1==2){
				cout<<"====To Other Networks===="<<endl;
				cout<<"1. MTN"<<endl;
				cout<<"2. AirtelTigo"<<endl;
				cout<<"Enter an option"<<endl;
				cin>>choice1;
				system("cls");
				
				if(choice1==1||choice1==2){
					cout<<"Enter recipient number"<<endl;
					cin>>Rnum;
					cout<<"Confirm recipient number"<<endl;
					cin>>Rnum1;
					system("cls");
					
						cout<<"Enter amount"<<endl;
						cin>>amount;
						system("cls");
						
						cout<<"Enter pin to confirm"<<endl;
						cin>>pin;
						system("cls");
						
						if(pin==default_pin&&Rnum==Rnum1){
							cout<<"You have successfully sent GHC: "<<amount<<" to "<<Rnum<<endl;
							cout<<"Your current balance is GHC: "<<default_balance-amount<<endl;
						}
						else if(Rnum!=Rnum1){
							cout<<"Numbers does not match...Enter number again"<<endl;
						}
						else{
							cout<<"Invalid number"<<endl;
						}
					}	
				}
			else if(option1==3){
				cout<<"Send to unregistered person"<<endl;
				cout<<"1.Yes  2.No"<<endl;
				cin>>choice2;
				system("cls");
				
				if(choice2==1){
					cout<<"Enter Mobile number"<<endl;
					cin>>Rnum;
					cout<<"Confirm Number"<<endl;
					cin>>Rnum1;
					system("cls");
					
						cout<<"Enter amount"<<endl;
						cin>>amount;
						system("cls");
						cout<<"Enter Pin"<<endl;
						cin>>pin;
						system("cls");
						
						if(pin==default_pin&&Rnum==Rnum1){
							cout<<"You have successfully sent GHC: "<<amount<<" as token to "<<Rnum<<endl;
							cout<<"Your current balance is GHC: "<<default_balance-amount<<endl;
						}
					
					else if(Rnum!=Rnum1){
						cout<<"Numbers does not match...Transaction Unsuccessful"<<endl;
					}
					else{
						cout<<"Invalid Number"<<endl;
					}
				}
			}
			else{
				cout<<"Invalid input"<<endl;
			}
			
			break;
		
		//withdraw cash menu
		case 2:
			cout<<"====Withdraw Cash===="<<endl;
			cout<<"1. From Agent"<<endl;
			cout<<"2. From ATM"<<endl;
			cout<<"Select an option"<<endl;
			cin>>option2;
			system("cls");
			
			if(option2==1){
				cout<<"Enter Till number"<<endl;
				cin>>tilnum;
				cout<<"Re-enter Till number"<<endl;
				cin>>tilnum1;
				system("cls");
				
				if(tilnum==tilnum1){
					cout<<"Enter withdrawal amount"<<endl;
					cin>>amount;
					system("cls");
					cout<<"You are making a withdrawal of GHC: "<<amount<<" from "<<agent_id<<endl;
					cout<<"Please enter pin to confirm withdrawal"<<endl;
					cin>>pin;
					system("cls");
					if(pin==default_pin){
						cout<<"You have successfully withdrawn GHC: "<<amount<<" from "<<agent_id<<endl;
						cout<<"Your current balance is GHC: "<<default_balance-amount<<endl;
					}
					else if(pin!=default_pin){
						cout<<"Incorrect pin...Withdrawal Unsuccessful"<<endl;
						cout<<"Try again later"<<endl;
					}
					else{
						cout<<"Invalid pin"<<endl;
					}
				}
				else if(tilnum!=tilnum1){
					cout<<"Till number does not match"<<endl;
					cout<<"Try again"<<endl;
				}
				else{
					cout<<"Invalid Till number"<<endl;
				}
			}
			else if(option2==2){
				cout<<"Enter pin to recieve voucher"<<endl;
				cin>>pin;
				system("cls");
				
				if(pin==default_pin){
					cout<<"Your request is being processed."<<endl;
					cout<<"Please wait for the confirmation short message"<<endl;
				}
			}
			break;
			
			//buy airtime or data menu
		case 3:
			cout<<"====Buy Airtime or Data===="<<endl;
			cout<<"1. Buy Airtime "<<endl;
			cout<<"2. Buy Data"<<endl;
			cout<<"3. Special Offers"<<endl;
			cout<<"Enter an option"<<endl;
			cin>>option3;
			system("cls");
			
			if(option3==1){
				cout<<"===Buy Airtime==="<<endl;
				cout<<"1. Self"<<endl;
				cout<<"2. Others"<<endl;
				cout<<"Enter your choice"<<endl;
				cin>>choice3;
				system("cls");
				if(choice3==1){
					cout<<"Buy airtime for self"<<endl;
					cout<<"Enter amount to buy"<<endl;
					cin>>amount;
					system("cls");
					cout<<"Enter pin to confirm purchase of GHC: "<<amount<<" airtime for self"<<endl;
					cin>>pin;
					system("cls");
					if(pin==default_pin){
						cout<<"You have successfully purchased GHC: "<<amount<<" airtime for yourself"<<endl;
						cout<<"Get 100% bonus when you buy airtime with vodafone cash"<<endl;
						cout<<"Your current momo balance is GHC: "<<default_balance-amount<<endl;
					}
					else if(pin!=default_pin){
						cout<<"Incorrect pin...Airtime purchase failed"<<endl;
					}
					else{
						cout<<"Invalid input"<<endl;
					}	
				}
				else if(choice3==2){
					cout<<"===Buy Airtime for others==="<<endl;
					cout<<"Enter phone number"<<endl;
					cin>>Rnum;
					system("cls");
					cout<<"Purchase of airtime GHC: "<<amount<<" to "<<Rnum<<endl;
					cout<<"Enter your pin to confirm purchase"<<endl;
					cin>>pin;
					system("cls");
					if(pin==default_pin){
						cout<<"You have successfully purchased GHC: "<<amount<<" airtime to "<<Rnum<<endl;
						cout<<"Your current balance is GHC: "<<default_balance-amount<<endl;	
					}
					else if(pin!=default_pin){
						cout<<"Incorrect pin...Enter pin again"<<endl;
					}
					else{
						cout<<"Invalid input"<<endl;
					}	
				}
			}
			else if(option3==2){
				cout<<"===Buy Data==="<<endl;
				cout<<"1. Buy for self"<<endl;
				cout<<"2. Buy for others"<<endl;
				cout<<"Enter an option"<<endl;
				cin>>input;
				system("cls");
				if(input==1){
				cout<<"===Buy Data for self==="<<endl;
					cout<<"Enter amount to buy "<<endl;
					cin>>amount;
					system("cls");
					cout<<"You are purchasing GHC: "<<amount<<" equivalent to "<<amount*50.8<<"MB to self"<<endl;
					cout<<"Enter your pin to confirm purchase "<<endl;
					cin>>pin;
					system("cls");
					if(pin==default_pin){
						cout<<"You have successfully purchased  "<<amount*50.8<<"MB of data to self"<<endl;
						cout<<"Get 50% bonus when you buy bundle with vodafone cash"<<endl;
						cout<<"Thank you "<<endl;
					}
					if(pin!=default_pin){
						cout<<"Incorrect pin...Bundle purchase unsuccessful"<<endl;
					}
					
					 }
				else if(input==2){
					cout<<"===Buy Bundle for Others==="<<endl;
					cout<<"Enter phone number"<<endl;
					cin>>Rnum;
					system("cls");
					cout<<"Enter Bundle amount"<<endl;
					cin>>amount;
					system("cls");
					cout<<"You are purchasing GHC: "<<amount<<" equivalent to "<<amount*50.8<<"MB to "<<Rnum<<endl;
					cout<<"Enter your pin to confirm"<<endl;
					cin>>pin;
					system("cls");
					if(pin==default_pin){
						cout<<"You have successfully purchased "<<amount*50.8<<"MB of data to "<<Rnum<<endl;
					}
					if(pin!=default_pin){
						cout<<"Incorrect pin...Bundle purchase unsuccessful"<<endl;
			    	}
				}	 
	    	}
			else if(option3==3){
				cout<<"THERE IS NO SPECIAL OFFER AVAILABLE RIGHT NOW"<<endl;	
			}
			else{
				cout<<"Invalid input"<<endl;
			}
			break;
			
		//financial services menu
		case 4:
			cout<<"===Financial Services==="<<endl;
			cout<<"1. Insurance"<<endl;
			cout<<"2. Loans"<<endl;
			cout<<"3. Savings"<<endl;
			cout<<"4. Overdraft"<<endl;
			cout<<"5. Bank Services"<<endl;
			cout<<"Enter an Option"<<endl;
			cin>>input1;
			system("cls");
			
			if(input1==1||input1==2||input1==3||input1==4){
					cout<<"Enter Your Pin"<<endl;
					cin>>pin;
					cout<<"SYSTEM NOT AVAILABLE RIGHT NOW"<<endl;
					cout<<"TRY AGAIN LATER... THANK YOU"<<endl;
				}
			else if(input1==5){
					cout<<"===Bank Services==="<<endl;
					cout<<"1. FIDELITY "<<endl;
					cout<<"2. ECOBANK"<<endl;
					cout<<"3. ABSA BANK"<<endl;
					cout<<"4. GCB "<<endl;
					cout<<"5. UBA"<<endl;
					cout<<"6. GN BANK"<<endl;
					cout<<"ENTER BANK CHOICE"<<endl;
					cin>>Bchoice;
					system("cls");
					if(Bchoice==1||Bchoice==2||Bchoice==3||Bchoice==4||Bchoice==5||Bchoice==6){
						cout<<"THIS SERVICE IS NOT AVAILABLE RIGHT NOW..."<<endl;
						cout<<"TRY AGAIN LATER...THANK YOU"<<endl;	
					}
					else{
						cout<<"WRONG INPUT...ENTER(1-6)"<<endl;
					}
		    	}
			else{
				cout<<"WRONG ENTRY...ENTER(1-6)"<<endl;
			    	}		
		    	break;
		
		//my account menu
		case 5:	
			cout<<"===MY ACCOUNT==="<<endl;
			cout<<"1. Check Balance"<<endl;
			cout<<"2. My Statements"<<endl;
			cout<<"3. Account Information"<<endl;
			cout<<"4. My lists"<<endl;
			cout<<"5. Help"<<endl;
			cout<<"Select Choice"<<endl;
			cin>>accountCH;	
			system("cls");
			if(accountCH==1){
				cout<<"Enter Your Pin"<<endl;
				cin>>pin;
				system("cls");
				if(pin==default_pin){	
				cout<<"YOUR ACCOUNT BALANCE IS GHC: "<<default_balance<<endl;
		    	}
		    	if(pin!=default_pin){
		    		cout<<"WRONG PIN !"<<endl;
		    		cout<<"ENTER THE CORRECT PIN"<<endl;
		    		cin>>pin;
		    		system("cls");
		    		if(pin==default_pin){
		    			cout<<"YOUR ACCOUNT BALANCE IS GHC: "<<default_balance<<endl;
					}
					else{
						cout<<"TOO MANY ATTEMPTS...ACCOUNT LOCKED!"<<endl;
						cout<<"ACCOUNT WILL BE OPENED AGAIN AFTER 24HRS..."<<endl;
					}
				}		
			}
			else if(accountCH==2){
				cout<<"Enter MoMo pin to get statements information"<<endl;
				cin>>pin;
				system("cls");
				if(pin==default_pin){
					cout<<"STATEMENTS WILL BE SENT THROUGH SMS IN A FEW MINUTES"<<endl;
					cout<<"THANK YOU..."<<endl;
				}
			}
			else if(accountCH==3){
				    cout<<"===Account Info==="<<endl;
				    cout<<"ACCOUNT NAME: "<<aCname<<endl;
				    cout<<"NUMBER: "<<aCnumber<<endl;
				    cout<<"DATE OF BIRTH: "<<aCrdate<<endl;
		    	}
			
			else if(accountCH==4){
				cout<<"YOU HAVE NO LISTS AVAILABLE..."<<endl;
				cout<<"THANK YOU !"<<endl;
			}
			else if(accountCH==5){
				cout<<"Call 030 222 5000 or visit www.vodafoneghana.com.gh for help"<<endl;
			}
			break;
			
		//make payments menu	
		case 6:
			cout<<"===Make Payments==="<<endl;
			cout<<"1. Pay Bill"<<endl;
			cout<<"2. Buy Goods"<<endl;
			cout<<"3. Fun and Games"<<endl;
			cout<<"Enter a choice"<<endl;
			cin>>mPayOpt;
			system("cls");
			if(mPayOpt==1){
				cout<<"===Pay Bill==="<<endl;
				cout<<"1. Electricity Bill "<<endl;
				cout<<"2. Water Bill"<<endl;
				cout<<"3. DSTV"<<endl;
				cout<<"4. GoTv"<<endl;
				cout<<"5. School Fees"<<endl;
				cout<<"Enter Choice"<<endl;
				cin>>bilOpt;
				system("cls");
				if(bilOpt==1||bilOpt==2||bilOpt==3||bilOpt==4||bilOpt==5){
					cout<<"SYSTEM UNDER SERVICE"<<endl;
					cout<<"TRY AGAIN LATER"<<endl;
					cout<<"THANK YOU !"<<endl;
		    	}
		    	else{
		    		cout<<"Incorrect Input"<<endl;
				}
			}
			else if(mPayOpt==2){
				cout<<"===Buy Goods==="<<endl;
				cout<<"1. KFC"<<endl;
				cout<<"2. Hubtel"<<endl;
				cout<<"3. Melcom"<<endl;
				cout<<"Enter Option"<<endl;
				cin>>buyGopt;
				system("cls");
				if(buyGopt==1||buyGopt==2||buyGopt==3){
					cout<<"SYSTEM NOT AVAILABLE RIGHT NOW"<<endl;
					cout<<"TRY AGAIN LATER"<<endl;
					cout<<"THANK YOU !"<<endl;
				}
				else{
					cout<<"INVALID INPUT"<<endl;
				}
			}
		
			else if	(mPayOpt==3){
			     cout<<"SYSTEM UNDER SERVICE"<<endl;
			     cout<<"TRY AGAIN LATER"<<endl;
			     cout<<"THANK YOU !"<<endl;
	        	}
	    	
	    	else{
	    		cout<<"INVALID INPUT"<<endl;
	    	}
		       break;
		 //self service menu      
		case 7:	
		    cout<<"===SELF SERVICE==="<<endl;
		    cout<<"1. Reset/ Change MoMo Pin"<<endl;
		    cout<<"2. Reverse Airtime to MoMo "<<endl;
		    cout<<"3. Help Services"<<endl;
		    cout<<"Choose an Option"<<endl;
		    cin>>ssOption;
		    system("cls");
		    if(ssOption==1){
		    	cout<<"Do You Want to Reset/ Change Your Pin ?"<<endl;
		    	cout<<"1) YES"<<endl;
		    	cout<<"2) NO"<<endl;
		    	cout<<"Choose Option"<<endl;
		    	cin>>Opt;
		    	system("cls");
		    	if(Opt==1){
		    		cout<<"Enter Old Pin"<<endl;
		    		cin>>pin;
		    		cout<<"Enter New pin"<<endl;
		    		cin>>new_pin;
		    		cout<<"Confirm New Pin"<<endl;
		    		cin>>new_pin1;
		    		system("cls");
		    		if(pin==default_pin&&new_pin==new_pin1){
		    			cout<<"PIN RESET SUCCESSFUL"<<endl;
					}
					if(pin==default_pin&&new_pin!=new_pin1){
						cout<<"NEW PIN DOES NOT MATCH"<<endl;
						cout<<"PIN RESET UNSUCCESSFUL"<<endl;
						cout<<"THANK YOU !"<<endl;
					}
					if(pin!=default_pin&&new_pin==new_pin1){
						cout<<"OLD PIN DOES NOT MATCH"<<endl;
						cout<<"ENTER THE CORRECT PIN"<<endl;
					}
				}
				else if(Opt==2){
					cout<<"PIN NOT RESETED"<<endl;
					cout<<"THANK YOU !"<<endl;
				}
				else{
					cout<<"INVALID OPTION"<<endl;
				}
			}
			else if(ssOption==2){
				cout<<"SYSTEM UNDER SERVICE"<<endl;
				cout<<"RE-TRY AFTER 24HRS"<<endl;
				cout<<"THANK YOU !"<<endl;
			}
			else if(ssOption==3){
				cout<<"CONTACT CUSTOMER SERVICE ON 030 222 5000 OR VISIT www.vodafoneghana.com.gh"<<endl;
			}
			else{
				cout<<"INVALID OPTION"<<endl;
			}
		    
		
		
       }
   
	
	
	return 0;
}
